# 0.0.4
-Renaming to match github versioning
-Hotfix for sprites layout

# 0.0.1
-Initial upload
